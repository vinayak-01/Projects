﻿Public Class Products

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ItemTableBindingSource.AddNew()
    End Sub

    Private Sub Products_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'SuperMDataSet.ItemTable' table. You can move, or remove it, as needed.
        Me.ItemTableTableAdapter.Fill(Me.SuperMDataSet.ItemTable)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        On Error GoTo SaveError

        ItemTableBindingSource.EndEdit()
        ItemTableTableAdapter.Update(SuperMDataSet)

        MsgBox("Data has been Saved")
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        ComboBox1.SelectedIndex = -1
SaveError:
        Exit Sub
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        ComboBox1.SelectedIndex = -1
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ItemTableBindingSource.RemoveCurrent()
    End Sub
    Dim key = 0
    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)

        TextBox4.Text = row.Cells(0).Value.ToString
        TextBox1.Text = row.Cells(1).Value.ToString
        TextBox2.Text = row.Cells(2).Value.ToString
        TextBox3.Text = row.Cells(3).Value.ToString
        ComboBox1.SelectedItem = row.Cells(4).Value.ToString

        If TextBox1.Text = "" Then
            key = 0
        Else
            key = Convert.ToInt32(row.Cells(1).Value.ToString)
        End If
    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click
        Me.Hide()
        Home.Show()
    End Sub
End Class