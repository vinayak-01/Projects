﻿Public Class Login
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim username As String
        Dim password As String
        username = TextBox1.Text
        password = TextBox2.Text

        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MessageBox.Show("Enter Username/Password", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf (username.Equals("admin") And password.Equals("admin")) Then
            MessageBox.Show("Login Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Me.Hide()
            Home.Show()
            TextBox1.Clear()
            TextBox2.Clear()
        Else
            MessageBox.Show("Wrong Username/Password", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error)
            TextBox1.Text = ""
            TextBox2.Text = ""
        End If
    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click
        Me.Close()
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click
        Me.Hide()
        Billing.Show()
    End Sub
End Class