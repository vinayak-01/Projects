﻿Public Class Billing
    Dim i = 0, Grdtotal = 0
    Dim selectedRowIndex As Integer
    Private Sub Billing_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'SuperMDataSet.ItemTable' table. You can move, or remove it, as needed.
        Me.ItemTableTableAdapter.Fill(Me.SuperMDataSet.ItemTable)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox4.Text = "" Or TextBox3.Text = "" Then
            MsgBox("Enter the Quantity")
        ElseIf TextBox1.Text = "" Then
            MsgBox("Select the Item")
        ElseIf stock < Convert.ToInt32(TextBox3.Text) Then
            MsgBox("Not Enough Stock")
            clear()
        Else
            Dim rnum As Integer = DataGridView2.Rows.Add
            i = i + 1
            Dim total = Convert.ToInt32(TextBox3.Text) * Convert.ToInt32(TextBox4.Text)
            DataGridView2.Rows.Item(rnum).Cells("Column1").Value = i
            DataGridView2.Rows.Item(rnum).Cells("Column2").Value = TextBox1.Text
            DataGridView2.Rows.Item(rnum).Cells("Column3").Value = TextBox4.Text
            DataGridView2.Rows.Item(rnum).Cells("Column4").Value = TextBox3.Text
            DataGridView2.Rows.Item(rnum).Cells("Column5").Value = total
            Grdtotal = Grdtotal + total
            Dim tot As String
            tot = "Rs " + Convert.ToString(Grdtotal)

            TextBox5.Text = tot
            UpdateItem()
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        clear()
    End Sub

    Private Sub clear()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        key = 0
        stock = 0
    End Sub

    Dim key = 0, stock = 0

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        MsgBox("The Receipt has been printed!")
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        DataGridView2.Rows.Clear()
    End Sub

    Private Sub DataGridView1_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)

        TextBox1.Text = row.Cells(2).Value.ToString
        TextBox4.Text = row.Cells(4).Value.ToString
        If TextBox1.Text = "" Then
            key = 0
        Else
            key = Convert.ToInt32(row.Cells(0).Value.ToString)
            stock = Convert.ToInt32(row.Cells(3).Value.ToString)
        End If
    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click
        Me.Hide()
        Login.Show()
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        selectedRowIndex = e.RowIndex
    End Sub

    Private Sub UpdateItem()

        Dim NewQty = stock - Convert.ToInt32(TextBox3.Text)
        Dim row As New DataGridViewRow
        row = DataGridView1.Rows(selectedRowIndex)
        row.Cells(3).Value = NewQty
        MsgBox("Item Added Successfully")
        If NewQty = 0 Then
            ItemTableBindingSource.RemoveCurrent()
        End If
        ItemTableBindingSource.EndEdit()
        ItemTableTableAdapter.Update(SuperMDataSet)
    End Sub
End Class