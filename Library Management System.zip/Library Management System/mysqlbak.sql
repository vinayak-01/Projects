-- MySQL dump 10.13  Distrib 5.1.48, for Win32 (ia32)
--
-- Host: localhost    Database: library
-- ------------------------------------------------------
-- Server version	5.1.48-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `issue`
--

DROP TABLE IF EXISTS `issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `issue` (
  `BOOK_ID` int(11) DEFAULT NULL,
  `Bname` varchar(30) DEFAULT NULL,
  `Edition` int(11) DEFAULT NULL,
  `Publisher` varchar(30) DEFAULT NULL,
  `Price` int(11) DEFAULT NULL,
  `pages` int(11) DEFAULT NULL,
  `S_ID` int(11) DEFAULT NULL,
  `SName` varchar(30) DEFAULT NULL,
  `F_name` varchar(30) DEFAULT NULL,
  `sclass` int(11) DEFAULT NULL,
  `section` varchar(30) DEFAULT NULL,
  `year` varchar(30) DEFAULT NULL,
  `DOI` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue`
--

LOCK TABLES `issue` WRITE;
/*!40000 ALTER TABLE `issue` DISABLE KEYS */;
INSERT INTO `issue` VALUES (1002,'Accounts',3,'T.S Grewal',300,700,826,'Ritik','Magandeep',10,'D','2018-19','2 Jan,2018'),(978,'Macro Economics',1,'Subash Dey',560,300,126,'Rohan','Rajiv',12,'COMMERCE','2018-19','5 Jan,2018'),(382,'Encyclopaedia',1,'Jack Challoner',600,300,689,'Aviral','Narinder',12,'COMMERCE','2018-19','6 Jan,2018');
/*!40000 ALTER TABLE `issue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nbook`
--

DROP TABLE IF EXISTS `nbook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nbook` (
  `BOOK_ID` int(11) DEFAULT NULL,
  `Name` varchar(30) DEFAULT NULL,
  `edition` int(11) DEFAULT NULL,
  `Publisher` varchar(30) DEFAULT NULL,
  `Price` int(11) DEFAULT NULL,
  `Pages` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nbook`
--

LOCK TABLES `nbook` WRITE;
/*!40000 ALTER TABLE `nbook` DISABLE KEYS */;
INSERT INTO `nbook` VALUES (1002,'Accounts',3,'T.S Grewal',300,700),(719,'Business Studies',1,'Poonam Gandhi',400,600),(413,'Biology',1,'Arihant',700,500),(382,'Encyclopaedia',1,'Jack Challoner',600,300),(364,'Micro Economics',1,'V.K Ohri',500,350),(978,'Macro Economics',1,'Subash Dey',560,300),(653,'English Speaking',1,'Kaushal Goel',440,150);
/*!40000 ALTER TABLE `nbook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `returnb`
--

DROP TABLE IF EXISTS `returnb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `returnb` (
  `S_ID` int(11) DEFAULT NULL,
  `SName` varchar(30) DEFAULT NULL,
  `F_name` varchar(30) DEFAULT NULL,
  `sclass` int(11) DEFAULT NULL,
  `section` varchar(30) DEFAULT NULL,
  `year` varchar(30) DEFAULT NULL,
  `BOOK_ID` int(11) DEFAULT NULL,
  `Bname` varchar(30) DEFAULT NULL,
  `Publisher` varchar(30) DEFAULT NULL,
  `Edition` int(11) DEFAULT NULL,
  `Price` int(11) DEFAULT NULL,
  `pages` int(11) DEFAULT NULL,
  `DOI` varchar(30) DEFAULT NULL,
  `DOR` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `returnb`
--

LOCK TABLES `returnb` WRITE;
/*!40000 ALTER TABLE `returnb` DISABLE KEYS */;
INSERT INTO `returnb` VALUES (9,'Kunal','Rajdeep',11,'SCIENCE','2018-19',1002,'Accounts','T.S Grewal',3,300,700,'1 Jan,2019','3 Jan,2019'),(899,'Jasraj','Akashdeep',12,'COMMERCE','2018-19',1002,'Accounts','T.S Grewal',3,300,700,'1 Jan,2019','5 Jan,2019'),(9,'Kunal','Rajdeep',11,'SCIENCE','2018-19',413,'Biology','Arihant',1,700,500,'1 Jan,2019','6 Jan,2019');
/*!40000 ALTER TABLE `returnb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `signup`
--

DROP TABLE IF EXISTS `signup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `signup` (
  `Username` varchar(30) DEFAULT NULL,
  `Name` varchar(30) DEFAULT NULL,
  `Security` varchar(50) DEFAULT NULL,
  `Answer` varchar(30) DEFAULT NULL,
  `Password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `signup`
--

LOCK TABLES `signup` WRITE;
/*!40000 ALTER TABLE `signup` DISABLE KEYS */;
INSERT INTO `signup` VALUES ('Vin01','Vinayak','Phone Number?','8872266646','sharma'),('Rohan1','Rohan Vermani','Favourite colour?','Yellow','Regency'),('Jodh1','Jodhvir Singh','Favourite Book?','Invisible Man','Phagwara'),('Gs2001','Gaurav','Phone Number?','1234567890','India');
/*!40000 ALTER TABLE `signup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `S_ID` int(11) DEFAULT NULL,
  `Name` varchar(30) DEFAULT NULL,
  `F_name` varchar(30) DEFAULT NULL,
  `sclass` int(11) DEFAULT NULL,
  `section` varchar(30) DEFAULT NULL,
  `year` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (899,'Jasraj','Akashdeep',12,'COMMERCE','2018-19'),(9,'Kunal','Rajdeep',11,'SCIENCE','2018-19'),(535,'Navdeep','Prakash',12,'HUMANITIES','2018-19'),(689,'Aviral','Narinder',12,'COMMERCE','2018-19'),(126,'Rohan','Rajiv',12,'COMMERCE','2018-19'),(12,'Amrit','Jagdeep',8,'C','2018-19'),(826,'Ritik','Magandeep',10,'D','2018-19'),(742,'Arjun','Raman',9,'B','2018-19'),(349,'Karan','Onkar',11,'HUMANITIES','2018-19');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-01-07  0:17:30
